///////////////////////////////////////////////////////////////////////////////
// LameXP - Audio Encoder Front-End
// Copyright (C) 2004-2010 LoRd_MuldeR <MuldeR2@GMX.de>
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
//
// http://www.gnu.org/licenses/gpl-2.0.txt
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include <iostream>
#include <fstream>
#include <limits.h>
#include <time.h>
#include <Windows.h>

using namespace std;

///////////////////////////////////////////////////////////////////////////////

#ifdef _MSC_VER
typedef __int64 int64_t;
#endif

#define ONE_SECOND ((ULONGLONG)(10 * 1000 * 1000))
#define ONE_MINUTE ((ULONGLONG)(60 * ONE_SECOND))

///////////////////////////////////////////////////////////////////////////////

ULONGLONG getCurrentTimeStamp(void)
{
	ULARGE_INTEGER timeStamp;
	memset(&timeStamp, 0, sizeof(ULARGE_INTEGER));

	SYSTEMTIME sysTime;
	FILETIME fileTime;
	GetSystemTime(&sysTime);
	
	if(SystemTimeToFileTime(&sysTime, &fileTime))
	{
		timeStamp.HighPart = fileTime.dwHighDateTime;
		timeStamp.LowPart = fileTime.dwLowDateTime;
	}

	return timeStamp.QuadPart;
}

///////////////////////////////////////////////////////////////////////////////

ULONGLONG getFileTimeStamp(const wchar_t *filename)
{
	ULARGE_INTEGER timeStamp;
	memset(&timeStamp, 0, sizeof(ULARGE_INTEGER));
	FILETIME created, lastAccess, lastWrite;

	HANDLE h = CreateFileW(filename, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, NULL, NULL);
	
	if(h == 0 || h == INVALID_HANDLE_VALUE)
	{
		return timeStamp.QuadPart;
	}
	
	if(GetFileTime(h, &created, &lastAccess, &lastWrite))
	{
		timeStamp.HighPart = lastWrite.dwHighDateTime;
		timeStamp.LowPart = lastWrite.dwLowDateTime;
	}

	CloseHandle(h);
	return timeStamp.QuadPart;
}

///////////////////////////////////////////////////////////////////////////////

void processLine(wchar_t *line, const wchar_t *name)
{
	int pos = 0;

	wchar_t buffer[4096];
	wchar_t output[4096];
	wchar_t spacer[4096];

	memset(buffer, 0, sizeof(wchar_t) * 4096);
	memset(output, 0, sizeof(wchar_t) * 4096);
	memset(spacer, 0, sizeof(wchar_t) * 4096);

	wcscpy_s(buffer, 4096, line);

	wchar_t *tokens[3];
	for(int i = 0; i < 3; i++) tokens[i] = NULL;

	wchar_t *context;
	wchar_t *token = wcstok_s(buffer, L" \t", &context);
	while(token && pos < 3)
	{
		tokens[pos++] = token;
		token = wcstok_s(NULL, L" \t", &context);
	}
	
	if(pos == 3 && !_wcsicmp(tokens[0], L"#define") && !_wcsicmp(tokens[1], name))
	{
		wcscat_s(output, 4096, tokens[0]);
		
		memset(spacer, 0, sizeof(wchar_t) * 4096);
		wcsncpy_s(spacer, 4096, line + ((tokens[0] - buffer) + wcslen(tokens[0])), tokens[1] - tokens[0] - wcslen(tokens[0]));
		wcscat_s(output, 4096, spacer);

		wcscat_s(output, 4096, tokens[1]);
		
		memset(spacer, 0, sizeof(wchar_t) * 4096);
		wcsncpy_s(spacer, 4096, line + ((tokens[1] - buffer) + wcslen(tokens[1])), tokens[2] - tokens[1] - wcslen(tokens[1]));
		wcscat_s(output, 4096, spacer);
		
		int value = _wtoi(tokens[2]);

		if(value > 0)
		{
			wchar_t temp[256];
			wcout << "Increased the value from " << value << " to " << value + 1 << "." << endl << endl;
			swprintf(temp, 256, L"%d", value + 1);
			wcscat_s(output, 4096, temp);
			wcscpy_s(line, 4096, output);
		}
	}
}

///////////////////////////////////////////////////////////////////////////////

int _tmain(int argc, _TCHAR* argv[])
{
	wcout << "AutoInc Tool [" << __DATE__ << "]" << endl;
	wcout << "Written by LoRd_MuldeR <MuldeR2@GMX.de>" << endl << endl;

	if(argc <= 2 || wcslen(argv[1]) < 1 || wcslen(argv[2]) < 1)
	{
		wcout << "Usage:" << endl << "  AutoInc.exe <macro_name> <header_file> [<min_interval_minutes>]" << endl;
		return -1;
	}
	
	int minInterval = 60;
	
	if(argc > 3)
	{
		int temp = _wtoi(argv[3]);
		if(temp > 0) minInterval = temp;
	}

	wcout << "Macro name:\t" << argv[1] << endl;
	wcout << "Header file:\t" << argv[2] << endl;
	wcout << "Interval:\t" << minInterval << " minute(s)" << endl << endl;

	ULONGLONG timeStamp = getFileTimeStamp(argv[2]);

	if(timeStamp <= 0)
	{
		wcout << "Could not read file time! Does file exist?" << endl;
		return -1;
	}

	ULONGLONG currentTime = getCurrentTimeStamp();
	
	if(timeStamp + static_cast<ULONGLONG>(ONE_MINUTE * minInterval) > currentTime)
	{
		wcout << "Skipping increase this time.";
		ULONGLONG delta = (timeStamp + static_cast<ULONGLONG>(ONE_MINUTE * minInterval)) - currentTime;
		if(delta >= ONE_MINUTE)
		{
			wcout << " Next update in " << static_cast<unsigned long>(delta / ONE_MINUTE) << " minute(s)." << endl << endl;
		}
		else
		{
			wcout << " Next update in " << static_cast<unsigned long>(delta / ONE_SECOND) << " seconds(s)." << endl << endl;
		}
		return 0;
	}

	wchar_t tempFile[4096];
	wchar_t tempPath[4096];
	GetTempPath(4096, tempPath);
	srand(static_cast<unsigned int>(time(NULL)));
	swprintf(tempFile, 4096, L"%s~autoinc.%04X%04X.tmp", tempPath, rand(), rand());
	
	wfstream file_in(argv[2], ios_base::in);
	wfstream file_out(tempFile, ios_base::out | ios_base::trunc);

	if(!file_in.good() || file_in.fail())
	{
		wcout << "Failed to open file for reading:\n" << argv[2] << endl << endl;
		file_in.close();
		file_out.close();
		return -1;
	}
	if(!file_out.good() || file_out.fail())
	{
		wcout << "Failed to open file for writing:\n" << tempFile << endl << endl;
		file_in.close();
		file_out.close();
		return -1;
	}
	
	wchar_t buffer[4096];

	while(file_in.good() && file_out.good() && !file_in.eof())
	{
		file_in.getline(buffer, 4096);
		if(file_in.eof()) break;
		processLine(buffer, argv[1]);
		file_out << buffer << endl;
	}
	
	file_in.close();
	file_out.close();

	wchar_t backupFile[4096];
	swprintf(backupFile, 4096, L"%s.bak", argv[2]);
	
	if(!CopyFileW(argv[2], backupFile, false))
	{
		wcout << "Failed to copy file:" << endl;
		wcout << argv[2] << " > " << backupFile << endl << endl;
	}
	else if(!CopyFileW(tempFile, argv[2], false))
	{
		wcout << "Failed to copy file:" << endl;
		wcout << tempFile << " > " << argv[2] << endl << endl;
	}

	DeleteFileW(tempFile);

	return 0;
}
